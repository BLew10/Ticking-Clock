var secondHand = document.querySelector("#seconds")
var minuteHand = document.querySelector("#minutes")
var hourHand = document.querySelector("#hour")
var second = 0;
var minute = 0;
var hour = 0;


function getSecondsSinceStartOfDay() {
    return new Date().getSeconds() +
        new Date().getMinutes() * 60 +
        new Date().getHours() * 3600;
}

setInterval(function () {
    var time = getSecondsSinceStartOfDay();
    console.log(time);
    second+=6;
    minute+=0.1;
    hour+=0.01;
    secondHand.style.transform = `rotate(${second}deg)`;
    minuteHand.style.transform = `rotate(${minute}deg)`;
    hourHand.style.transform = `rotate(${hour}deg)`;
}, 1000);


